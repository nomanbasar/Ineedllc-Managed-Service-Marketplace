from rest_framework.views import APIView
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework import status

from .permissions import IsAdminUserRole
from .models import ServiceCategory, Service, ServiceHour, ServiceAdditionalFeature
from .serializers import (
    ServiceCategorySerializer,
    ServiceSerializer,
    ServiceHourSerializer,
    ServiceAdditionalFeatureSerializer,
)


# =========================
# PUBLIC APIs (frontend)
# =========================

class PublicCategoryList(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        qs = ServiceCategory.objects.filter(is_active=True).order_by("category_name")
        return Response({"success": True, "message": "category_list", "data": ServiceCategorySerializer(qs, many=True).data})


class PublicServiceList(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        qs = Service.objects.filter(is_active=True).select_related("category_id").order_by("-created_at")

        category_id = request.query_params.get("category_id")
        search = request.query_params.get("search")

        if category_id:
            qs = qs.filter(category_id_id=category_id)
        if search:
            qs = qs.filter(name__icontains=search)

        return Response({"success": True, "message": "service_list", "data": ServiceSerializer(qs, many=True).data})


# =========================
# ADMIN APIs (create/update)
# =========================

class AdminCategoryListCreate(APIView):
    permission_classes = [IsAuthenticated, IsAdminUserRole]

    def get(self, request):
        qs = ServiceCategory.objects.all().order_by("-created_at")
        return Response({"success": True, "message": "admin_category_list", "data": ServiceCategorySerializer(qs, many=True).data})

    def post(self, request):
        s = ServiceCategorySerializer(data=request.data)
        s.is_valid(raise_exception=True)
        obj = s.save()
        return Response({"success": True, "message": "category_created", "data": ServiceCategorySerializer(obj).data}, status=status.HTTP_201_CREATED)


class AdminCategoryDetail(APIView):
    permission_classes = [IsAuthenticated, IsAdminUserRole]

    def put(self, request, category_id):
        obj = ServiceCategory.objects.get(id=category_id)
        s = ServiceCategorySerializer(obj, data=request.data)
        s.is_valid(raise_exception=True)
        obj = s.save()
        return Response({"success": True, "message": "category_updated", "data": ServiceCategorySerializer(obj).data})

    def delete(self, request, category_id):
        obj = ServiceCategory.objects.get(id=category_id)
        obj.delete()
        return Response({"success": True, "message": "category_deleted"})


class AdminServiceListCreate(APIView):
    permission_classes = [IsAuthenticated, IsAdminUserRole]

    def get(self, request):
        qs = Service.objects.all().order_by("-created_at")
        return Response({"success": True, "message": "admin_service_list", "data": ServiceSerializer(qs, many=True).data})

    def post(self, request):
        s = ServiceSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        obj = s.save()
        return Response({"success": True, "message": "service_created", "data": ServiceSerializer(obj).data}, status=status.HTTP_201_CREATED)


class AdminServiceDetail(APIView):
    permission_classes = [IsAuthenticated, IsAdminUserRole]

    def put(self, request, service_id):
        obj = Service.objects.get(id=service_id)
        s = ServiceSerializer(obj, data=request.data)
        s.is_valid(raise_exception=True)
        obj = s.save()
        return Response({"success": True, "message": "service_updated", "data": ServiceSerializer(obj).data})

    def delete(self, request, service_id):
        obj = Service.objects.get(id=service_id)
        obj.delete()
        return Response({"success": True, "message": "service_deleted"})


class AdminServiceHourCreate(APIView):
    permission_classes = [IsAuthenticated, IsAdminUserRole]

    def post(self, request):
        s = ServiceHourSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        obj = s.save()
        return Response({"success": True, "message": "service_hour_created", "data": ServiceHourSerializer(obj).data}, status=status.HTTP_201_CREATED)


class AdminAdditionalFeatureCreate(APIView):
    permission_classes = [IsAuthenticated, IsAdminUserRole]

    def post(self, request):
        # ✅ supports multipart/form-data (image upload)
        s = ServiceAdditionalFeatureSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        obj = s.save()

        return Response({
            "success": True,
            "message": "additional_feature_created",
            "data": ServiceAdditionalFeatureSerializer(obj).data
        }, status=status.HTTP_201_CREATED)


class AdminAdditionalFeatureList(APIView):
    permission_classes = [IsAuthenticated, IsAdminUserRole]

    def get(self, request):
        service_id = request.query_params.get("service_id")
        qs = ServiceAdditionalFeature.objects.all().order_by("-created_at")

        if service_id:
            qs = qs.filter(service_id_id=service_id)

        return Response({
            "success": True,
            "message": "additional_feature_list",
            "data": ServiceAdditionalFeatureSerializer(qs, many=True).data
        })
