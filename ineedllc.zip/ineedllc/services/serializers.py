from rest_framework import serializers
from .models import ServiceCategory, Service, ServiceHour, ServiceAdditionalFeature


class ServiceCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = ServiceCategory
        fields = [
            "id",
            "category_icon_upload",
            "category_name",
            "subtitle",
            "is_active",
            "created_at",
            "updated_at",
        ]


class ServiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Service
        fields = [
            "id",
            "category_id",
            "name",
            "description",
            "man_price",
            "offer_price",
            "discount",
            "image",
            "is_active",
            "created_at",
            "updated_at",
        ]


class ServiceHourSerializer(serializers.ModelSerializer):
    class Meta:
        model = ServiceHour
        fields = ["id", "service_id", "day_of_week", "from_time", "to_time", "is_closed", "created_at"]


class ServiceAdditionalFeatureSerializer(serializers.ModelSerializer):
    class Meta:
        model = ServiceAdditionalFeature
        fields = [
            "id",
            "service_id",
            "additional_features_title",
            "subtitle",
            "additional_features_price",
            "additional_features_image",
            "estimate_time",
            "estimate_time_unit",
            "created_at",
            "updated_at",
        ]
